#!/bin/sh
java -Djava.class.path=jagexappletviewer.jar -Dcom.jagex.config=http://w1.04scaper.ca:5001/java_config.ws -Xmx128m -Xss2m jagexappletviewer lostcity